def main() -> int:
    print("hello from nuro")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

